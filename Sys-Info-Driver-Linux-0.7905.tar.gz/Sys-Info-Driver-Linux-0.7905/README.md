we forked it because there is test failures and no one fix it now.
See https://github.com/binary-com/perl-Sys-Info-Driver-Linux/pull/1
